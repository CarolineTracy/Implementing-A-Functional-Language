(*!tests!
*
* { "output": ["4"] }
*
*)
8 - 4 ;;
