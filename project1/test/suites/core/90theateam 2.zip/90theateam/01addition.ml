(*!tests!
*
* { "output": ["7"] }
*
*)
3 + 4 ;;
