(*!tests!
*
* { "output": ["true"] }
*
*)

true ;; 

